package com.droiddeck.launcher.core

import android.content.Context
import com.droiddeck.launcher.session.SessionPrefs
import com.droiddeck.launcher.stores.xbox.XboxCloudSettings
import com.droiddeck.launcher.stores.xbox.XboxNativeVideo

/**
 * Named sets of settings DroidDeck already has. Choosing a profile writes them once; any of them can still be
 * changed afterwards, and the profile then shows as custom. Nothing here touches CPU or GPU clocks, thermal
 * limits or Android's own settings: the session refresh cap, the FEX preset, where the Steam client runs,
 * performance hints for game threads, Steam's shader pre-caching and downloads, and the Xbox Cloud stream.
 */
object PerformanceProfiles {
    const val BALANCED = "balanced"
    const val PERFORMANCE = "performance"
    const val BATTERY = "battery"
    const val COMPATIBILITY = "compatibility"
    const val XBOX = "xbox"
    const val XBOX_CLOUD = "xbox_cloud"
    const val STEAM = "steam"
    const val CUSTOM = ""

    val all = listOf(BALANCED, PERFORMANCE, BATTERY, COMPATIBILITY, XBOX, XBOX_CLOUD, STEAM)

    private const val FEX_DEFAULT = "PERFORMANCE_TSO"

    /** Xbox Cloud settings a profile sets; null leaves the current value. */
    data class Cloud(
        val playerEngine: String? = null,
        val resolution: String? = null,
        val fpsLimit: Int? = null,
        val bitrateMbps: Int? = null,
        val frameGen: String? = null,
        val smallBuffer: Boolean? = null,
        val fastDecoder: Boolean? = null,
        val zeroCopy: Boolean? = null,
    ) {
        fun applyTo(s: XboxCloudSettings) = s.copy(
            playerEngine = playerEngine ?: s.playerEngine, resolution = resolution ?: s.resolution,
            fpsLimit = fpsLimit ?: s.fpsLimit, fpsCustomOn = if (fpsLimit != null) false else s.fpsCustomOn,
            bitrateMbps = bitrateMbps ?: s.bitrateMbps, frameGen = frameGen ?: s.frameGen,
            smallBuffer = smallBuffer ?: s.smallBuffer, fastDecoder = fastDecoder ?: s.fastDecoder, zeroCopy = zeroCopy ?: s.zeroCopy,
        )

        fun holds(s: XboxCloudSettings) = applyTo(s) == s
    }

    /** What a profile sets; null leaves the current value. clientCores "" means every core (no pinning). */
    data class Plan(
        val refreshCap: Int? = null,
        val fexPreset: String? = null,
        val clientCores: String? = null,
        val pinGamescope: Boolean? = null,
        val gameThreadHints: Boolean? = null,
        val shaderPrecache: Boolean? = null,
        val steamDownloadsInBackground: Boolean? = null,
        val cloud: Cloud? = null,
    )

    /**
     * lowTier: LowTierDevice.detected (Adreno 6xx below the 630, e.g. Snapdragon 685). little: CpuCores.littleCores(),
     * "" on a CPU with one cluster.
     */
    fun plan(profile: String, lowTier: Boolean, little: String): Plan {
        val cap60 = if (lowTier) 60 else 0
        val noFrameGen = if (lowTier) XboxNativeVideo.FG_OFF else null
        return when (profile) {
            // DroidDeck's own defaults for this device.
            BALANCED -> Plan(refreshCap = SessionPrefs.defaultRefreshCap(lowTier), fexPreset = FEX_DEFAULT, clientCores = "",
                pinGamescope = true, gameThreadHints = false,
                cloud = Cloud(resolution = "1080p", fpsLimit = 0, bitrateMbps = 0,
                    frameGen = if (lowTier) XboxNativeVideo.FG_OFF else XboxNativeVideo.FG_DDFG, smallBuffer = false, fastDecoder = true))
            // The game gets the fast cores: the Steam client and its web helper (x86-64 under FEX on an ARMv8.0 CPU) move
            // to the efficiency cluster, gamescope stays free; Android is asked to keep the busiest game threads fed;
            // no background shader compiling on a low-tier GPU; the stream takes the lowest-latency path.
            PERFORMANCE -> Plan(refreshCap = cap60, fexPreset = FEX_DEFAULT, clientCores = little, pinGamescope = false,
                gameThreadHints = true, shaderPrecache = if (lowTier) false else null,
                cloud = Cloud(fpsLimit = 0, frameGen = noFrameGen, smallBuffer = true, fastDecoder = true, zeroCopy = true))
            // Half the frames (30 Hz session, an exact divisor of 60 Hz), everything but the game on the efficiency
            // cluster, no background work, a 720p stream at 8 Mb/s with the screen at 60 Hz.
            BATTERY -> Plan(refreshCap = 30, fexPreset = FEX_DEFAULT, clientCores = little, pinGamescope = true,
                gameThreadHints = false, shaderPrecache = false, steamDownloadsInBackground = false,
                cloud = Cloud(resolution = "720p", fpsLimit = 60, bitrateMbps = 8, frameGen = XboxNativeVideo.FG_OFF,
                    smallBuffer = false, fastDecoder = true))
            // FEX keeps x86 memory ordering everywhere (vector and memcpy included) and full x87 precision: slower,
            // for games that crash or glitch otherwise. The stream uses the web engine with normal buffering.
            COMPATIBILITY -> Plan(refreshCap = cap60, fexPreset = "COMPATIBILITY", clientCores = "", pinGamescope = true,
                gameThreadHints = false,
                cloud = Cloud(playerEngine = "web", frameGen = noFrameGen, smallBuffer = false, fastDecoder = false, zeroCopy = false))
            // Xbox PC games installed from the Xbox store run locally through Proton: like PERFORMANCE, at a steady
            // 30 fps on a low-tier GPU, the usual target of these titles on weak hardware.
            XBOX -> Plan(refreshCap = if (lowTier) 30 else 0, fexPreset = FEX_DEFAULT, clientCores = little, pinGamescope = false,
                gameThreadHints = true, shaderPrecache = if (lowTier) false else null)
            // Streaming only: the console renders, this device decodes. Best picture the panel shows, lowest latency.
            XBOX_CLOUD -> Plan(cloud = Cloud(resolution = "1080p", fpsLimit = 0, bitrateMbps = 0, frameGen = noFrameGen,
                smallBuffer = true, fastDecoder = true, zeroCopy = true))
            STEAM -> Plan(refreshCap = cap60, fexPreset = FEX_DEFAULT, clientCores = little, pinGamescope = false,
                gameThreadHints = true, shaderPrecache = if (lowTier) false else null)
            else -> Plan()
        }
    }

    fun plan(context: Context, profile: String) =
        plan(profile, LowTierDevice.detected, CpuCores.littleCores())

    fun apply(context: Context, profile: String) {
        if (profile !in all) return
        val p = plan(context, profile)
        p.refreshCap?.let { SessionPrefs.setRefreshCap(context, it) }
        p.fexPreset?.let { SessionPrefs.setFexPreset(context, it) }
        p.clientCores?.let {
            SessionPrefs.setClientCpusOverride(context, it.isNotEmpty())
            SessionPrefs.setClientCpus(context, it)
        }
        p.pinGamescope?.let { SessionPrefs.setPinGamescope(context, it) }
        p.gameThreadHints?.let { SessionPrefs.setGameThreadHintsEverywhere(context, it) }
        p.shaderPrecache?.let { SessionPrefs.setShaderPrecache(context, it) }
        p.steamDownloadsInBackground?.let { SessionPrefs.setSteamDownloadsInBackground(context, it) }
        p.cloud?.let { XboxCloudSettings.save(context, it.applyTo(XboxCloudSettings.load(context))) }
        SessionPrefs.setPerformanceProfile(context, profile)
    }

    /** The chosen profile while every setting it wrote still holds, else CUSTOM. Shader pre-caching is not compared:
     *  Steam can rewrite it. */
    fun current(context: Context): String {
        val id = SessionPrefs.performanceProfile(context)
        if (id !in all) return CUSTOM
        val p = plan(context, id)
        val held = (p.refreshCap == null || SessionPrefs.refreshCap(context) == p.refreshCap) &&
            (p.fexPreset == null || SessionPrefs.fexPreset(context) == p.fexPreset) &&
            (p.clientCores == null || (if (p.clientCores.isEmpty()) !SessionPrefs.clientCpusOverride(context)
                else SessionPrefs.clientCpusOverride(context) && SessionPrefs.clientCpus(context) == p.clientCores)) &&
            (p.pinGamescope == null || SessionPrefs.pinGamescope(context) == p.pinGamescope) &&
            (p.gameThreadHints == null || SessionPrefs.gameThreadHintsEverywhere(context) == p.gameThreadHints) &&
            (p.steamDownloadsInBackground == null || SessionPrefs.steamDownloadsInBackground(context) == p.steamDownloadsInBackground) &&
            (p.cloud == null || p.cloud.holds(XboxCloudSettings.load(context)))
        return if (held) id else CUSTOM
    }
}
