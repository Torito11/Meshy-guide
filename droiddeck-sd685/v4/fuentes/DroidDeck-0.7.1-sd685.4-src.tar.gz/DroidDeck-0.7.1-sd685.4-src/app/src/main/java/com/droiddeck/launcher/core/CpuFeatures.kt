package com.droiddeck.launcher.core

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Whether the CPU has the ARMv8.1 LSE atomic instructions (HWCAP_ATOMICS).
 *
 * Valve's arm64 Steam client (libtier0_s.so's ThreadInterlockedIncrement is a bare `ldaddal`)
 * and every arm64 Proton build (Valve's Makefile uses -march=armv8.2-a) use LSE atomics without a
 * runtime check, so they stop with SIGILL on ARMv8.0 cores such as the Cortex-A53/A73 in the
 * Snapdragon 6xx and 835 families. FEX needs only ARMv8.0 with FP and CRC32.
 */
object CpuFeatures {
    enum class Lse { PRESENT, ABSENT, UNKNOWN }

    private const val AT_NULL = 0L
    private const val AT_HWCAP = 16L
    private const val HWCAP_ATOMICS = 1L shl 8

    internal fun lseFromAuxv(auxv: ByteArray?): Lse {
        if (auxv == null || auxv.size < 16) return Lse.UNKNOWN
        val buffer = ByteBuffer.wrap(auxv).order(ByteOrder.LITTLE_ENDIAN)
        while (buffer.remaining() >= 16) {
            val type = buffer.long
            val value = buffer.long
            if (type == AT_NULL) break
            if (type == AT_HWCAP) return if ((value and HWCAP_ATOMICS) != 0L) Lse.PRESENT else Lse.ABSENT
        }
        return Lse.UNKNOWN
    }

    /** Every core's list must name `atomics`; no Features line at all says nothing either way. */
    internal fun lseFromCpuInfo(cpuInfo: String?): Lse {
        val lists = cpuInfo.orEmpty().lineSequence()
            .filter { it.substringBefore(':').trim() == "Features" }
            .map { line -> line.substringAfter(':').trim().split(Regex("\\s+")).filter(String::isNotEmpty).toSet() }
            .toList()
        if (lists.isEmpty()) return Lse.UNKNOWN
        return if (lists.all { "atomics" in it }) Lse.PRESENT else Lse.ABSENT
    }

    internal fun combine(auxv: Lse, cpuInfo: Lse): Lse = if (auxv != Lse.UNKNOWN) auxv else cpuInfo

    val lse: Lse by lazy {
        if (System.getProperty("os.arch").orEmpty().let { it != "aarch64" && it != "arm64" }) return@lazy Lse.UNKNOWN
        combine(
            lseFromAuxv(runCatching { File("/proc/self/auxv").readBytes() }.getOrNull()),
            lseFromCpuInfo(FileUtils.readString(File("/proc/cpuinfo"))),
        )
    }

    /** True only when the CPU is known to lack LSE: absent or unreadable data keeps every arm64 path. */
    fun armv80Only(): Boolean = lse == Lse.ABSENT

    fun describe(): String = when (lse) {
        Lse.PRESENT -> "ARMv8.1+ (LSE atomics)"
        Lse.ABSENT -> "ARMv8.0 (no LSE atomics): Valve's arm64 Steam client and arm64 Proton cannot run"
        Lse.UNKNOWN -> "not reported"
    }
}
