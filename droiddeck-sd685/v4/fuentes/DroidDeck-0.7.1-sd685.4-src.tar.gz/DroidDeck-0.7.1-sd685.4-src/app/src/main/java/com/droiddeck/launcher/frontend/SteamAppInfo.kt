package com.droiddeck.launcher.frontend

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

object SteamAppInfo {
    private const val TAG = "SteamAppInfo"
    private const val CACHE = "steam-appinfo.json"
    private const val RETRY_AFTER_MS = 7L * 24 * 3600 * 1000
    const val SHARED_APP = "228980"

    class Info(val name: String, val sharedDepots: List<String>)

    fun appinfoFile(context: Context) = File(com.droiddeck.launcher.session.SessionPrefs.activeSteamRoot(context), "appcache/appinfo.vdf")

    @Synchronized
    fun info(context: Context, appId: Int, appinfo: File = appinfoFile(context)): Info? {
        val cacheFile = AtomicFile(File(context.filesDir, CACHE))
        val cache = runCatching { JSONObject(cacheFile.readFully().toString(Charsets.UTF_8)) }.getOrDefault(JSONObject())
        val now = System.currentTimeMillis()
        val mtime = appinfo.lastModified()
        val known = cache.optJSONObject(appId.toString())
        known?.let { o ->
            if (!o.optBoolean("miss")) return Info(o.optString("name"), o.optJSONArray("depots").strings())
            if (now - o.optLong("at") < RETRY_AFTER_MS && o.optLong("mtime") == mtime) return null
        }
        val read = runCatching { read(appinfo, appId) }.onFailure { Log.w(TAG, "appinfo: ${it.javaClass.simpleName}") }.getOrNull()
        val entry = JSONObject().put("at", now).put("mtime", mtime)
        known?.optLong("picsAt")?.takeIf { it > 0 }?.let { entry.put("picsAt", it) }
        if (read == null) entry.put("miss", true) else entry.put("name", read.name).put("depots", JSONArray(read.sharedDepots))
        cache.put(appId.toString(), entry)
        val out = cacheFile.startWrite()
        try { out.write(cache.toString().toByteArray()); cacheFile.finishWrite(out) } catch (e: Exception) { cacheFile.failWrite(out) }
        return read
    }

    @androidx.annotation.VisibleForTesting
    internal var pics: (List<Int>) -> Map<Int, Info?>? = { SteamPics.lookup(it) }

    fun needLookup(context: Context, appIds: List<Int>): List<Int> {
        val wanted = appIds.distinct().filter { it > 0 && info(context, it) == null }
        if (wanted.isEmpty()) return emptyList()
        val cache = cache(context)
        val now = System.currentTimeMillis()
        return wanted.filter { now - (cache.optJSONObject(it.toString())?.optLong("picsAt") ?: 0L) >= RETRY_AFTER_MS }
    }

    @Synchronized
    fun lookup(context: Context, appIds: List<Int>): Boolean {
        val need = needLookup(context, appIds)
        if (need.isEmpty()) return false
        val answers = pics(need) ?: return false
        val cache = cache(context)
        val now = System.currentTimeMillis()
        val mtime = appinfoFile(context).lastModified()
        for (id in need) {
            val info = answers[id]
            val entry = JSONObject().put("at", now).put("mtime", mtime).put("picsAt", now)
            if (info == null) entry.put("miss", true) else entry.put("name", info.name).put("depots", JSONArray(info.sharedDepots)).put("source", "pics")
            cache.put(id.toString(), entry)
        }
        val file = AtomicFile(File(context.filesDir, CACHE))
        val out = file.startWrite()
        try { out.write(cache.toString().toByteArray()); file.finishWrite(out) } catch (e: Exception) { file.failWrite(out) }
        return true
    }

    fun state(context: Context, appId: Int): String = cache(context).optJSONObject(appId.toString())?.let { if (it.optBoolean("miss")) "miss" else "hit" } ?: "none"

    private fun cache(context: Context): JSONObject =
        runCatching { JSONObject(AtomicFile(File(context.filesDir, CACHE)).readFully().toString(Charsets.UTF_8)) }.getOrDefault(JSONObject())

    private fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else (0 until length()).map { optString(it) }

    internal fun read(file: File, appId: Int): Info? {
        if (!file.isFile) return null
        RandomAccessFile(file, "r").use { raf ->
            val head = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN)
            raf.readFully(head.array(), 0, 8)
            val magic = head.getInt(0)
            val version = magic and 0xFF
            if (magic ushr 8 != 0x075644 || version !in 0x27..0x29) return null
            var strings: List<String>? = null
            var pos = 8L
            if (version >= 0x29) {
                raf.readFully(head.array(), 8, 8)
                val tableAt = head.getLong(8)
                strings = readStrings(raf, tableAt)
                pos = 16L
            }
            val fixed = if (version >= 0x28) 4 + 4 + 8 + 20 + 4 + 20 else 4 + 4 + 8 + 20 + 4
            val entry = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            while (pos + 8 <= raf.length()) {
                raf.seek(pos)
                raf.readFully(entry.array(), 0, 8)
                val id = entry.getInt(0)
                val size = entry.getInt(4).toLong() and 0xFFFFFFFFL
                if (id == 0) return null
                if (id == appId) {
                    if (size > 64L * 1024 * 1024) return null
                    val body = ByteArray(size.toInt())
                    raf.readFully(body)
                    val kv = ByteBuffer.wrap(body, fixed, body.size - fixed).order(ByteOrder.LITTLE_ENDIAN)
                    val tree = readMap(kv, strings)
                    @Suppress("UNCHECKED_CAST")
                    val app = (tree["appinfo"] as? Map<String, Any>) ?: tree
                    return infoOf(app)
                }
                pos += 8 + size
            }
            return null
        }
    }

    @Suppress("UNCHECKED_CAST")
    internal fun infoOf(app: Map<String, Any>): Info {
        val name = (app["common"] as? Map<String, Any>)?.get("name") as? String ?: ""
        val depots = (app["depots"] as? Map<String, Any>).orEmpty()
        val shared = depots.mapNotNull { (key, value) ->
            val depot = value as? Map<String, Any> ?: return@mapNotNull null
            key.takeIf { (depot["depotfromapp"] as? String) == SHARED_APP || (key in SteamRedists.DEPOTS && depot["sharedinstall"] != null) }
        }
        return Info(name, shared)
    }

    private fun readStrings(raf: RandomAccessFile, at: Long): List<String> {
        raf.seek(at)
        val count = Integer.reverseBytes(raf.readInt())
        val rest = ByteArray((raf.length() - at - 4).toInt().coerceAtLeast(0))
        raf.readFully(rest)
        val out = ArrayList<String>(count)
        var start = 0
        for (i in rest.indices) {
            if (out.size == count) break
            if (rest[i] == 0.toByte()) { out.add(String(rest, start, i - start, Charsets.UTF_8)); start = i + 1 }
        }
        return out
    }

    private fun cstring(b: ByteBuffer): String {
        val start = b.position()
        while (b.get() != 0.toByte()) { }
        val bytes = ByteArray(b.position() - start - 1)
        b.position(start); b.get(bytes); b.get()
        return String(bytes, Charsets.UTF_8)
    }

    internal fun readMap(b: ByteBuffer, strings: List<String>?): Map<String, Any> {
        val out = LinkedHashMap<String, Any>()
        while (b.hasRemaining()) {
            val type = b.get().toInt() and 0xFF
            if (type == 0x08) return out
            val key = if (strings != null) strings.getOrElse(b.int) { "" } else cstring(b)
            when (type) {
                0x00 -> out[key] = readMap(b, strings)
                0x01 -> out[key] = cstring(b)
                0x02 -> out[key] = b.int.toString()
                0x03 -> out[key] = b.float.toString()
                0x07, 0x0A -> out[key] = b.long.toString()
                else -> return out
            }
        }
        return out
    }
}
