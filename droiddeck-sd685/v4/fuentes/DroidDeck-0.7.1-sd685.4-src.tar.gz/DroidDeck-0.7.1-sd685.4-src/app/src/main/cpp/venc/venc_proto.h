#ifndef DROIDDECK_VENC_PROTO_H
#define DROIDDECK_VENC_PROTO_H

#include <stdint.h>

#define VENC_MAX_BUFFERS 16

enum venc_msg { VENC_CONFIG = 1, VENC_FRAME = 2, VENC_DONE = 3, VENC_BITRATE = 4, VENC_TOUCH = 5, VDEC_CONFIG = 6, VDEC_CAPTURE = 7, VDEC_PACKET = 8, VDEC_RESULT = 9 };
enum venc_touch_action { VENC_TOUCH_DOWN = 0, VENC_TOUCH_MOVE = 1, VENC_TOUCH_UP = 2 };
enum venc_codec { VENC_H264 = 0, VENC_HEVC = 1 };

struct venc_config {
    uint32_t type;
    uint32_t codec;
    uint32_t width, height, stride, rows;
    uint32_t fps_num, fps_den;
    uint32_t bitrate, peak_bitrate, vbr;
    uint32_t gop;
    int32_t profile, level;
    uint32_t inputs, outputs;
    uint32_t input_size, output_size;
};

struct venc_frame {
    uint32_t type;
    uint32_t input, output;
    uint32_t bytes;
    uint32_t keyframe;
    int64_t pts_us;
};

struct venc_done {
    uint32_t type;
    int32_t status;
    uint32_t bytes;
    uint32_t keyframe;
};

struct venc_bitrate {
    uint32_t type;
    uint32_t bitrate;
};

struct venc_touch {
    uint32_t type;
    uint32_t action;
    uint32_t x, y;
};

struct vdec_config {
    uint32_t type;
    uint32_t codec;
    uint32_t width, height;
    uint32_t stride, rows;
    uint32_t bitstreams, bitstream_size;
};

struct vdec_capture {
    uint32_t type;
    uint32_t index;
    uint32_t size;
};

struct vdec_packet {
    uint32_t type;
    uint32_t input, bytes, capture;
    int64_t pts_us;
};

struct vdec_result {
    uint32_t type;
    int32_t status;
    uint32_t frame;
};

#endif
