package com.droiddeck.launcher.core

import com.droiddeck.launcher.gpu.GpuInfo

/**
 * Snapdragon 4xx/6xx-class hardware: an Adreno 6xx below the 630 (A605-A620), or any CPU without
 * ARMv8.1 atomics. Only defaults follow from it; every setting it touches stays the user's choice.
 */
object LowTierDevice {
    internal fun isLowTier(family: GpuInfo.Family, model: Int, armv80Only: Boolean): Boolean =
        armv80Only || (family == GpuInfo.Family.A6XX && model in 600..629)

    val detected: Boolean by lazy {
        runCatching { GpuInfo.detect() }.getOrNull()
            .let { gpu -> isLowTier(gpu?.family ?: GpuInfo.Family.NOT_ADRENO, gpu?.model ?: 0, CpuFeatures.armv80Only()) }
    }
}
